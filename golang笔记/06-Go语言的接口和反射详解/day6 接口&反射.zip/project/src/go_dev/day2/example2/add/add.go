package add

import(
	 _ "go_dev/day2/example2/test"
)



func init () {
	Name = "hello world"
	Age = 10
	
}

var Name string = "xxxxx"
var Age int = 100
