package main

import "fmt"

func main() {
	// fmt.Println("你好golang")
	fmt.Println("你好golang")

}
