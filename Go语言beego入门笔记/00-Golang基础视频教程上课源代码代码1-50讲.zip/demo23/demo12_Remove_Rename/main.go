package main

func main() {

	// /1、删除一个文件
	// err := os.Remove("aaa.txt")
	// if err != nil {
	// 	fmt.Println(err)
	// }

	//2、删除一个目录
	// err := os.Remove("./aaa")
	// if err != nil {
	// 	fmt.Println(err)
	// }

	// 3、一次删除多个文件
	// err := os.RemoveAll("dir1")
	// if err != nil {
	// 	fmt.Println(err)
	// }

}
