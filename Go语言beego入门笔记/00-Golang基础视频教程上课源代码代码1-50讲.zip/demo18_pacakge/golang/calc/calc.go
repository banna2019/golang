package calc

import "fmt"

func init() {
	fmt.Println("calc init..")
}

func Add(x, y int) int {
	return x + y
}
