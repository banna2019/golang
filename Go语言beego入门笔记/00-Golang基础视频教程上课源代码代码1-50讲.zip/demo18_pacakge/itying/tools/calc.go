package tools

func Mul(x, y int) int {
	return x * y
}
